self.__precacheManifest = [
  {
    "revision": "8e006cbb33fba7efad99",
    "url": "/static/css/main.7dc81674.chunk.css"
  },
  {
    "revision": "8e006cbb33fba7efad99",
    "url": "/static/js/main.f413909e.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "ecd05f5733a69fb5ea5a",
    "url": "/static/css/2.52084e24.chunk.css"
  },
  {
    "revision": "ecd05f5733a69fb5ea5a",
    "url": "/static/js/2.45041a12.chunk.js"
  },
  {
    "revision": "01af271b5d7567a0fcfa525e7dbd0b34",
    "url": "/static/media/ban.01af271b.jpg"
  },
  {
    "revision": "f8e47a1d09d589eddb3c61a6aabcf172",
    "url": "/static/media/noconnect.f8e47a1d.png"
  },
  {
    "revision": "2af85ec7d3e1813604666196527ee4db",
    "url": "/index.html"
  }
];